<?php
function nepaliwp_settings_menu() {
 	add_menu_page( 
	'Nepali WP Settings', 
	'Nepali WP', // menu name
	'manage_options', 
	'nepaliwp_settings', // setting name
	'nepaliwp_settings_page', // function to render 
	NEPALIWP_PLUGIN_URL . '/assest/img/menuicon.png',31
	);
 
 
 /* remove duplicate menu hack */
add_submenu_page(
    'nepaliwp_settings',        // parent slug, same as above menu slug
    '',        // empty page title
    '',        // empty menu title
    'edit_themes',        // same capability as above
    'nepaliwp_settings',        // same menu slug as parent slug
    ''        // same function as above
);
 
	add_submenu_page( 'nepaliwp_settings', 'nepalidate', 'Nepali Date','manage_options', 'admin.php?page=nepaliwp_settings&tab=nepali-date', /*$function*/'' );
	add_submenu_page( 'nepaliwp_settings', 'nepalitype', 'Nepali Type','manage_options', 'admin.php?page=nepaliwp_settings&tab=nepali-roman-converter','' );
	//add_submenu_page( 'nepaliwp_settings', 'popularnews', 'Popular News','manage_options', 'admin.php?page=nepaliwp_settings&tab=popular-news', '' );
	//add_submenu_page( 'nepaliwp_settings', 'developer', 'Developer','manage_options', 'admin.php?page=nepaliwp_settings&tab=developer','' );
	//add_submenu_page( 'nepaliwp_settings', 'more', '+More','manage_options', 'admin.php?page=nepaliwp_settings&tab=more','' );

	}
add_action( 'admin_menu', 'nepaliwp_settings_menu' );



function nepaliwp_tabs () {
$tabs = array(
		//slug => title 
		'setting'=>'Nepali WP',
		'nepali-date'=>'Date Options',
		'nepali-roman-converter'=> 'Nepali Roman Unicode'
		//'popular-news'=> 'Popular News',
		//'developer'=> 'Developer',
		//'more'=> 'More...'
		);
		/*CREATE NEW TABS 
			-tabslug/
				-index.php (empty)
				-modal.php (setting fields)
				-view.php  (do setting / view form)
		*/ 	
		return $tabs;
}

/** Settings Page Content **/
function nepaliwp_settings_page() { 
$tabs = nepaliwp_tabs ();


?>




    <div class="wrap">
	<h2>Welcome To Nepali WP</h2>
		<?php settings_errors();?>	
<h2 class="nav-tab-wrapper">
		<?php $active_tab = 'setting'; if( isset( $_GET[ 'tab' ] ) ) {$active_tab = $_GET[ 'tab' ];} // end if
		foreach($tabs as $tabslug=>$tabtitle){ ?>
		<a href="?page=nepaliwp_settings&tab=<?= $tabslug; ?>" class="nav-tab <?php echo $active_tab == $tabslug ? 'nav-tab-active' : ''; ?>"><?= $tabtitle; ?></a>
		<?php }?>
 </h2>
        <form method="post" action="options.php">
            <?php
			foreach($tabs as $tabslug=>$tabtitle){
		    if($active_tab==$tabslug){@require_once($tabslug.'/view.php');}
			}
			?>
        </form>
    </div>
 
    <?php
	
			//GET MODAL.PHP
		
			
			
}
			$tabs = nepaliwp_tabs ();
	        $active_tab = 'nepali-date';
			foreach($tabs as $tabslug=>$tabtitle){
			if($active_tab==$tabslug){require_once($tabslug.'/modal.php');}
			}
?>