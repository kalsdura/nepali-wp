 <?php 
$url = "https://docs.google.com/spreadsheet/pub?key=1K2kFRR-DYuO7UzVxU5mvNSY9C2njeTOCM7aDxzyWT5o&single=true&gid=0&output=csv";
$row=0;
if (($handle = @fopen($url, "r")) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $num = count($data);
        $row++;
        for ($c=0; $c < $num; $c++) {
          echo $data[$c].' ';
        }
    }
    fclose($handle);
}else{$html = "<h1>Nepal WP Team</h1> <p class='description'>Developing wordpress based websites since 2010.</p>";
			echo ($html);}
			?>