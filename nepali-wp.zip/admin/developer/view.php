<script language="JavaScript" src="<?= NEPALIWP_PLUGIN_URL . '/assest/' ?>js/jquery.js"></script>
<script type="text/javascript" language="javascript">	
$(document).ready(function(){

$.ajax(
	{
		type: "POST",
		// dataType: "json",
		url: "<?= NEPALIWP_PLUGIN_URL . '/admin/developer/'?>modal.php",
		//url:'http://localhost/wptests/developers',
		data: {nwp:'developer',type:'html',query:'',bucket:''},
		success: function(data) 
		{
			$('#nepaliwp_dev').html(data);
			$( ".nepaliwp_loading_box" ).hide();
		} ,
		error: function (XMLHttpRequest, textStatus, errorThrown) 
		{
			$( ".nepaliwp_loading_box" ).html('Error.')
		}

	});
		
	

})
</script>

<div class ="nepaliwp_loading_box"><img src="<?= NEPALIWP_PLUGIN_URL . '/assest/img/loading.gif' ?>"/> Loading...</div>
<div id="nepaliwp_dev">
</div>
<p class="description">You can also join the team , email us at <a href="mailto:<?= NEPALIWP_PLUGIN_EMAIL ?>"><?= NEPALIWP_PLUGIN_EMAIL ?></a>
</p>