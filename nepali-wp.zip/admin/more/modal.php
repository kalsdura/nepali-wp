 <?php 
 /* NEPALIWP MORE */
$url = "https://docs.google.com/spreadsheet/pub?key=1JWNBu5t1aIDV55G_O_PWyJA0G_cg0T8S-xrxawHvTac&single=true&gid=0&output=csv";
$row=0;
if (($handle = @fopen($url, "r")) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
        $num = count($data);
        $row++;
        for ($c=0; $c < $num; $c++) {
          echo $data[$c].' ';
        }
    }
    fclose($handle);
}else{$html = "<h1>More</h1><p>Keep visiting this page for surprises.</p>";
			echo ($html);}
			?>