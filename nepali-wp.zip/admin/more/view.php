<script language="JavaScript" src="<?= NEPALIWP_PLUGIN_URL . '/assest/' ?>js/jquery.js"></script>
<script type="text/javascript" language="javascript">	
$(document).ready(function(){

$.ajax(
	{
		type: "POST",
		// dataType: "json",
		url: "<?= NEPALIWP_PLUGIN_URL . '/admin/more/'?>modal.php",
		data: '',
		success: function(data) 
		{
			// $( "#popnews_status" ).html( " " );
			$('#nepaliwp_more').html(data);
			$( ".nepaliwp_loading_box" ).hide();
		} ,
		error: function (XMLHttpRequest, textStatus, errorThrown) 
		{
			$( ".nepaliwp_loading_box" ).html('Error.')
		}

	});
		
	

})
</script>

<div class ="nepaliwp_loading_box"><img src="<?= NEPALIWP_PLUGIN_URL . '/assest/img/loading.gif' ?>"/> Loading...</div>
<div class="topSpace"></div>
<div id="nepaliwp_more">
</div>