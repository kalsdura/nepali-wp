<?php
date_default_timezone_set('Asia/Katmandu');
//filter for post date
add_filter('get_the_date', 'my_np_date');
//filter for comment date
add_filter( 'get_comment_date', 'my_np_date' );	

function my_np_date( $content ) {

//DEFAULT OPTION VALUES OF NEPALI WP DATE
$npwp = array();
$npwp = get_option('nepaliwp_date');
$npwp_template = $npwp['date_format']; 
$sp = $npwp['separator']; 
$bd = $npwp['before_date'];
$bt = $npwp['before_time'];
$ad = $npwp['after_date'];
$st = @$npwp['show_time'];

if(isset($npwp['disable_date'])){
	if($npwp['disable_date']==true){
	return $content;
	}
}


$date = date_parse(date('Y-m-d h:i:s',get_the_time('U')));
if ($date) {
$cal = new Nepali_Calendar();
$nepdate = $cal->eng_to_nep($date['year'], $date['month'], $date['day']);
$yn = $nepdate['year'];
$mn = $nepdate['month'];
$mn_name = $nepdate['nmonth'];
$dn = $nepdate['date'];
$dn_name = $nepdate['day'];
$np_hr = $cal->vasa_convert_n($date['hour']);
$np_min = $cal->vasa_convert_n($date['minute']);
$np_yn = $cal->vasa_convert_n($yn);
$np_mn = $cal->vasa_convert_n($mn);
$np_mn_name = $cal->vasa_convert_m($mn);
$np_dn = $cal->vasa_convert_n($dn);
$np_dn_name = $cal->vasa_convert_d($dn_name);
$postTime = "";
if(isset($st)){
$postTime = " , $bt $np_hr : $np_min";
}








switch($npwp_template){
    case "a":
        $content = "$np_yn $sp $np_mn_name $sp $np_dn $np_dn_name";
        break;
    case "b":
        $content = "$np_yn $sp $np_mn_name $sp $np_dn";
        break;
    case "c":
        $content = "$np_yn $sp $np_mn $sp $np_dn";
        break;	
    case "d":
        $content = "$yn $sp $mn_name $sp $dn $dn_name";
        break;	
    case "e":
        $content = "$yn $sp $mn_name $sp $dn";
        break;	
    case "f":
        $content = "$yn $sp $mn $sp $dn";
        break;			
    default:
        $content = "$np_yn $sp $np_mn_name $sp $np_dn , $np_dn_name";
        break;
}
$content ="$bd $content $ad $postTime";
return $content;
}
return $content;
}
?>