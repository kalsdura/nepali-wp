<?php 
/** Settings Initialization **/
function nepaliwp_settings_init() {
	//Advanced customization
	/** Setting section 3. **/
    add_settings_section(
    /*1*/   'nepaliwp_settings_section_1',
    /*2*/   '', //first tab title
    /*3*/   'nepaliwp_settings_section_1_callback',
    /*4*/   'nepaliwp_settings'
    );
	//Adding Array
	add_settings_field(
    /*1*/   'date_format',
    /*2*/   'Date Format',
    /*3*/   'nepaliwp_date_format_input',
    /*4*/   'nepaliwp_settings',
    /*5*/   'nepaliwp_settings_section_1'
    );
	add_settings_field(
    /*1*/   'separator',
    /*2*/   'Separator',
    /*3*/   'nepaliwp_separator_input',
    /*4*/   'nepaliwp_settings',
    /*5*/   'nepaliwp_settings_section_1'
    );
	// Field person name.
	add_settings_field(
    /*1*/   'before_date',
    /*2*/   'Before Date',
    /*3*/   'nepaliwp_before_date_input',
    /*4*/   'nepaliwp_settings',
    /*5*/   'nepaliwp_settings_section_1'
    );
    add_settings_field(
    /*1*/   'after_date',
    /*2*/   'After Date',
    /*3*/   'nepaliwp_after_date_input',
    /*4*/   'nepaliwp_settings',
    /*5*/   'nepaliwp_settings_section_1'
    );
		// Field person name.
	add_settings_field(
    /*1*/   'before_time',
    /*2*/   'Before Time',
    /*3*/   'nepaliwp_before_time_input',
    /*4*/   'nepaliwp_settings',
    /*5*/   'nepaliwp_settings_section_1'
    );
	add_settings_field(
    /*1*/   'show_time',
    /*2*/   '',
    /*3*/   'nepaliwp_show_time_input',
    /*4*/   'nepaliwp_settings',
    /*5*/   'nepaliwp_settings_section_1'
    );
	add_settings_field(
    /*1*/   'disable_date',
    /*2*/   '',
    /*3*/   'nepaliwp_disable_date_input',
    /*4*/   'nepaliwp_settings',
    /*5*/   'nepaliwp_settings_section_1'
    );
	register_setting( 'nepaliwp_settings_group', 'nepaliwp_date' ); 
	
	
	

}
add_action( 'admin_init', 'nepaliwp_settings_init' );




 

// Custom Section Callback
function nepaliwp_settings_section_1_callback() {
 
    echo( '' ); // subheading or function to callback first title
}
 

 
 
 

/** FIELD DATE FORMAT **/
function nepaliwp_date_format_input() {
$options = array(
'a'=>'&#2408;&#2406;&#2410;&#2414;  &#2330;&#2376;&#2340;&#2381;&#2352;  &#2408;&#2411;  &#2358;&#2369;&#2325;&#2381;&#2352;&#2348;&#2366;&#2352;',
'b'=>'&#2408;&#2406;&#2410;&#2414;  &#2330;&#2376;&#2340;&#2381;&#2352;  &#2408;&#2411; ',
'c'=>'&#2408;&#2406;&#2410;&#2414;  &#2407;&#2408;  &#2408;&#2411; ',
'd'=>'2048 Ashwin 25, Friday ',
'e'=>'2048 Ashwin 25 ',
'f'=>'2048 12 25 '
);
  $npwp_dt = get_option( 'nepaliwp_date' );
  $current = $npwp_dt['date_format'];

 // Build <select> element.
    $html = '<select id="nepaliwp_date[date_format]" name="nepaliwp_date[date_format]">';
 
    foreach ( $options as $value => $text )
    {
        $html .= '<option value="'. $value .'"';
 
        // We make sure the current options selected.
        if ( $value == $current ) $html .= ' selected="selected"';
 
        $html .= '>'. $text .'</option>';
    }
     
    $html .= '</select>';
 
    echo( $html );  
	
 }
 
 /** FIELD DATE SEPARATOR **/
function nepaliwp_separator_input() {
    $options = get_option( 'nepaliwp_date' );
	?>
	<input type='text' name='nepaliwp_date[separator]' value='<?php echo $options['separator']; ?>' placeholder="optional eg | , . - "/>
	<code class="description">Your Custom separator like , | - </code>
	<?php
 }  
 
 /** FIELD BEFORE DATE **/
function nepaliwp_before_date_input() {
    $options = get_option( 'nepaliwp_date' );
	?>
	
	<input type='text' name='nepaliwp_date[before_date]' value='<?php echo $options['before_date']; ?>' placeholder="optional eg DATE:"/>
	<code>eg: &#2350;&#2367;&#2340;&#2367; : , Date : etc</code>
	<?php
 } 
 
    /** FIELD AFTER DATE**/
function nepaliwp_after_date_input() {
    $options = get_option( 'nepaliwp_date' );
	?>
	<input type='text' name='nepaliwp_date[after_date]' value='<?php echo $options['after_date']; ?>' placeholder="optional"/>
	<p class="description">Optional</p>
	<?php
 }
 /** FIELD BEFORE DATE **/
function nepaliwp_before_time_input() {
    $options = get_option( 'nepaliwp_date' );
	?>

	<input type='text' name='nepaliwp_date[before_time]' value='<?php echo $options['before_time']; ?>' placeholder="optional eg Time:"/>
	<code>eg: Time HH:MM</code>
	<?php
 } 
    /** FIELD disable DATE**/
function nepaliwp_show_time_input() {
    $options = get_option( 'nepaliwp_date' );
	?>
	<input name="nepaliwp_date[show_time]" type="checkbox" id="nepaliwp_date[show_time]" value="1" <?php if(isset( $options['show_time'])){  checked(1,$options['show_time'] );  }?>>
Show Time
	<?php } 
    /** FIELD disable DATE**/
function nepaliwp_disable_date_input() {
    $options = get_option( 'nepaliwp_date' );
	?>
	<input name="nepaliwp_date[disable_date]" type="checkbox" id="nepaliwp_date[disable_date]" value="1" <?php if(isset( $options['disable_date'])){  checked(1,$options['disable_date'] );  }?>>
Disable Nepali Date
	<?php } ?>