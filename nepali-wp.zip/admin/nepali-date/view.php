<?php 
do_settings_sections( 'nepaliwp_settings' );
settings_fields( 'nepaliwp_settings_group' );
// Submit button.
submit_button(); 
?>