<style>
.intrinsic-containera {
display:block;
clear:both;
min-height:50%;
margin-bottom:20px;
width:100%;


}
/* Custom, iPhone Retina */ 
    @media only screen and (min-width : 320px) {
        .intrinsic-containera { width:300px;}
    }

    /* Extra Small Devices, Phones */ 
    @media only screen and (min-width : 480px) {
.intrinsic-containera { width:480px;}
    }

    /* Small Devices, Tablets */
    @media only screen and (min-width : 768px) {
.intrinsic-containera { width:700px;}
    }

    /* Medium Devices, Desktops */
    @media only screen and (min-width : 992px) {
.intrinsic-containera { width:900px;}
    }

    /* Large Devices, Wide Screens */
    @media only screen and (min-width : 1200px) {
.intrinsic-containera { width:960px;}
    }
#unicode-iframe {
height: 100vh;
min-height:100vh;
}
</style>
<div class="intrinsic-container"><br/>
<p class="description" id="closehelp">
<code>Help</code>
ta = त , 
Ta = ट , 
tha = थ  , 
Tha = ठ , 
da = द , 
Da = ड , 
dha = ध , 
Dha = ढ , 
na = न , 
Na = ण , 
sha = श , 
Sha = ष   &nbsp;<a href="#helpHere">view all</a></p>
<iframe id="unicode-iframe" src= <?=NEPALIWP_PLUGIN_URL.'/admin/nepali-roman-converter/nepali-roman-converter.html'?> width="100%" height="420" style=" border:0px; padding-top:20px" border="0"></iframe>
</div>
<h2 id="helpHere"></h2>
<h2 > Need Help ? <a href="#wpbody-content">Close Help</a> </h2> <br/><b>1. To mix English into your Nepali text.</b>
<p class="description">Simply put any text you want to keep in English inside the curly {} brackets. Example: <code> yo {mobile} mero ho. = यो mobile मेरो ह</code></p>
 <br>
 <table cellpadding="10">
 <tr>

 <td cellspacing="1" valign="top" > <b>2. Phonetically similar letters:</b> <br/>
ta = त <br> 
Ta = ट<br> 
tha = थ<br> 
Tha = ठ<br> 
da = द<br> 
Da = ड<br> 
dha = ध<br> 
Dha = ढ<br> 
na = न<br> 
Na = ण<br> 
sha = श<br> 
Sha = ष <br> 
The (upper or lower) case doesn’t<br/> matter for the rest of the letters2
</td>
 <td cellspacing="1" valign="top" >
 <b>3. Other special characters:</b> <br>
ri^ = रि (as in प्र)<br>
rr = र्‍ (as in गर्‍य)<br>
rri = ऋ<br>
rree = ॠ<br>
yna = ञ<br>
chha = छ<br>
ksha =क्ष<br>
gya =ज्ञ<br>
* = अनुस्वर<br>
** = चन्द्रबिन्दु<br>
om = ॐ<br>
 </td>
 </tr>
 </table>
 