<?php //Nepali WP By Ramesh Dura
function emptynews() {
$news = array(
"version" => "1.0" , 
"updated" => "2015-03-30",
"isempty" => "true",
"allNews" => array
			(

				
				array
				(
				'title'=>'', 
				'desc'=>'',
				'image'=>'',
				'newsLink'=>'',
				'date'=>'',
				'sourceLink'=>'',
				'source'=>''
				)
				
			)

);

 return json_encode($news);
}

 ?>
 
  <?php 
$url = "https://docs.google.com/spreadsheet/pub?key=13Qe5GP_TvjrK8_DEsj5qHOsgA66Z7DA09CF8NW59Qc4&single=true&gid=0&output=csv";
$row=0;
if (($handle = @fopen($url, "r")) !== FALSE) {
    while (($data = fgetcsv($handle, 1000, ",")) !== FALSE) {
	$news = $data[0];
	echo $news;
    }
    fclose($handle);
}else{
$html = emptynews();
echo ($html);}
			?>