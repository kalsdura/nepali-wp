<script language="JavaScript" src="<?= NEPALIWP_PLUGIN_URL . '/assest/' ?>js/jquery.js"></script>
<script type="text/javascript" language="javascript">	
$(document).ready(function(){

//OUTPUT TEMPLATE
function genereate_news(image,title,description,newsLink,date,sourceLink,source) {
var oneNews = '<div class="pin"><a><img src="'+image+'" /><h3>'+title+'</h3></a><p class="desc">'+description+'<a href="'+newsLink+'" target="_blank">Read More</a></p><p class="description nepaliwp_news_meta"> Posted on '+date+'  by <a href="'+sourceLink+'" target="_blank">'+source+'</a></p></div>';
return oneNews;
}
//AJAX CALL DATA FROM MODAL
$.ajax({
      type: "POST",
      dataType: "json",
      url: "<?= NEPALIWP_PLUGIN_URL . '/admin/popular-news/'?>modal.php",
	  // url: 'http://localhost/wptests/developers',
      data: {nwp:'popular-news'},
	success: function(data) {
		var news = data['allNews'];
		var isempty = data['isempty'];
		if(isempty == "true"){ $( ".nepaliwp_loading_box" ).hide();  } else 
		{

			for (var i = 0; i < news.length; i++) {
				//alert(news[i].title);
				var n = news[i];
				$( "#columns" ).append( genereate_news(n.image,n.title,n.desc,n.newsLink,n.date,n.sourceLink,n.source) );
			}
			$( ".nepaliwp_loading_box" ).hide(); 
		}
	} ,
			
		error: function (XMLHttpRequest, textStatus, errorThrown) 
		{
			$( ".nepaliwp_loading_box" ).html('Error.')
		}	
			
		});
		
	

})
</script>
<div class ="nepaliwp_loading_box"><img src="<?= NEPALIWP_PLUGIN_URL . '/assest/img/loading.gif' ?>"/> Loading...</div>
<div id="columns" class="ppnews">
</div>
<p class="description">Disclaimer : All the news above are the property of their respective websites so mentioned. We are just providing a common place for information. We respect and encourage creative writing. 
For adding your content on this wall please contact us at <a href="mailto:<?= NEPALIWP_PLUGIN_EMAIL ?>"><?= NEPALIWP_PLUGIN_EMAIL ?></a>
</p>

			
			