<?php
/*
Plugin Name: Nepali WP
Version: 1.0
Description: Nepali WP is purely developed for helping wordpess sites that are using devnagari as their main language. Currently we have a wordpress nepali date , nepali roman unicode converter and a most popular news section. Nepali Wp is designed and developed by Ramesh Dura. 
Author: Ramesh Dura / Kalsdura
Author URI: http://www.facebook.com/kalsdura
Plugin URI: http://wordpress.org/
Text Domain: 
License: A short license name. Example: GPL2
*/ 

if (!defined('NEPALIWP_PLUGIN_NAME'))
    define('NEPALIWP_PLUGIN_NAME', trim(dirname(plugin_basename(__FILE__)), '/'));

if (!defined('NEPALIWP_PLUGIN_DIR'))
    define('NEPALIWP_PLUGIN_DIR', WP_PLUGIN_DIR . '/' . NEPALIWP_PLUGIN_NAME);

if (!defined('NEPALIWP_PLUGIN_URL'))
    define('NEPALIWP_PLUGIN_URL', WP_PLUGIN_URL . '/' . NEPALIWP_PLUGIN_NAME);
	
if (!defined('NEPALIWP_PLUGIN_VERSION'))
    define('NEPALIWP_PLUGIN_VERSION', '1.0');
	
if (!defined('NEPALIWP_PLUGIN_EMAIL'))
    define('NEPALIWP_PLUGIN_EMAIL', 'nepaliwp@gmail.com');

	

// Register Script
function nepali_wp_assest() {
		if(isset($_GET['page'])){
		if($_GET['page'] == 'nepaliwp_settings'){
			wp_register_style( 'nepali_wp_css', NEPALIWP_PLUGIN_URL . '/assest/css/style.css', false, '1.0' );
			wp_enqueue_style( 'nepali_wp_css' );
			
			wp_deregister_script( 'nepali_wp_js' );
			wp_register_script( 'nepali_wp_js',  NEPALIWP_PLUGIN_URL . '/assest/js/nepaliwp.js', false, '1.0', false );
			wp_enqueue_script( 'nepali_wp_js' );

		}
		}
}
	
	
// if admin add setting page and setting page link 
if(is_admin()){
//2. Adding setting page link
add_filter('plugin_action_links', 'nepaliwp_plugin_action_links', 10, 2);
function nepaliwp_plugin_action_links($links, $file) {
    static $this_plugin;

    if (!$this_plugin) {
        $this_plugin = plugin_basename(__FILE__);
    }

    if ($file == $this_plugin) {
        // The "page" query string value must be equal to the slug
        // of the Settings admin page we defined earlier, which in
        // this case equals "myplugin-settings".
        $settings_link = '<a href="' . get_bloginfo('wpurl') . '/wp-admin/admin.php?page=nepaliwp_settings">Settings</a>';
        array_unshift($links, $settings_link);
    }

    return $links;

}
// Hook into the 'admin_enqueue_scripts' action
add_action( 'admin_enqueue_scripts', 'nepali_wp_assest' );
require_once('admin/admin.php');
}



// Load on front end
if(!isset($npwp['disable_date'])){
require_once('admin/nepali-date/nepali_calendar.php');
require_once('admin/nepali-date/functions.php');
}


?>
