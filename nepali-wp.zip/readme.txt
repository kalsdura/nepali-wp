=== Nepali Date Dura ===
Contributors: Ramesh Dura ( From Nepal )
Donate link: http://www.facebook.com/kalsdura
Tags: nepal, nepali,  post, date, converter
Requires at least: 3.2
Tested up to: 4.1.1
Stable tag: 1.13
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

With help of this plugin you can display post dates in nepali time format. 

== Description ==

If your site is in nepali unicode and your date is in english , dont worry this plugin will convert english date into nepali. you can even show dates in nepali unicode.
= Main Features =
Showing Nepali dates
== Installation ==

1. Upload `nepali-date-dura` folder to the `/wp-content/plugins/` directory.
2. Activate the plugin through the 'Plugins' menu in WordPress.
3. Enable the Widget through the Appearance --> Widgets tab.
4. Edit the widget Settings in your widget Administration Panel.

== Frequently Asked Questions ==

= Can I request a feature? =

Yes, please do so on the WordPress support forum for the plugin. I will consider it and if I feel it is worth adding, I will schedule it for a future release.

== To-Do List ==

This is the list of some features, that I planning to add in next versions of plugin. Please [donate](https://www.paypal.com/cgi-bin/webscr?cmd=_s-xclick&hosted_button_id=GSE37FC4Y7CEY) to help me make all this things.

* Post public wall api.
* Roman Nepali converter.

= 1.00 =
* First Release